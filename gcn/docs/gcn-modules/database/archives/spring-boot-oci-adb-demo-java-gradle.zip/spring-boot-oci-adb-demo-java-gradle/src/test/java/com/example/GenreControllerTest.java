// Copyright (c) 2024, Oracle.
// Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl.
package com.example;

import com.example.domain.Genre;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class GenreControllerTest {
    @LocalServerPort
    int port;

    @Autowired
    private RestTemplateBuilder builder;

    private RestTemplate template;

    @BeforeEach
    void setUp() {
        template = builder.rootUri("http://localhost:" + port).build();
    }

    @Test
    public void testFindNonExistingGenreReturnsNull() {
        assertNull(template.getForObject("/genres/99", Genre.class));
    }

    @Test
    public void testGenreCrudOperations() {

        List<Long> genreIds = new ArrayList<>();

        ResponseEntity<Genre> response = template.postForEntity("/genres", "DevOps", Genre.class);
        genreIds.add(entityId(response));

        assertEquals(HttpStatus.CREATED, response.getStatusCode());

        response = template.postForEntity("/genres", "Microservices", Genre.class);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());

        Long id = entityId(response);
        genreIds.add(id);

        Genre genre = template.getForObject("/genres/" + id, Genre.class);

        assertEquals("Microservices", genre.name());

        template.put("/genres", new GenreUpdateCommand(id, "Micro-services"));

        genre = template.getForObject("/genres/" + id, Genre.class);
        assertEquals("Micro-services", genre.name());

        List<?> genres = template.getForObject("/genres/list", List.class);
        assertEquals(2, genres.size());

        response = template.postForEntity("/genres/ex", "Microservices", Genre.class);

        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());

        genres = template.getForObject("/genres/list", List.class);
        assertEquals(2, genres.size());

        for(Long genreId : genreIds) {
            template.delete("/genres/" + genreId);
        }
        genres = template.getForObject("/genres/list", List.class);
        assertEquals(0, genres.size());
    }

    private Long entityId(ResponseEntity<Genre> response) {
        String path = "/genres/";
        String value = response.getHeaders().getLocation().getPath();
        if (value == null) {
            return null;
        }
        int index = value.indexOf(path);
        if (index != -1) {
            return Long.valueOf(value.substring(index + path.length()));
        }
        return null;
    }

}
