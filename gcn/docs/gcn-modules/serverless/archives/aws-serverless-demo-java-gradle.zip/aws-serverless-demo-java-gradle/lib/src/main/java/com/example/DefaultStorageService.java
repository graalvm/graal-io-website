/*
 * Copyright 2023 Oracle and/or its affiliates
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example;

import io.micronaut.context.annotation.Requires;
import io.micronaut.core.annotation.NonNull;
import jakarta.inject.Singleton;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Singleton
@Requires(missingBeans = StorageService.class)
class DefaultStorageService implements StorageService {

    protected List<StoreItem> items = List.of(
        new StoreItem("chair", "A black chair with 4 legs", 10),
        new StoreItem("table", "A quality dining table", 6),
        new StoreItem("sofa", "A grey sofa", 2),
        new StoreItem("bookshelf", "A futuristic-looking bookshelf", 0)
    );

    @Override
    public Collection<StoreItem> getItems() {
        return items;
    }

    @Override
    public Optional<StoreItem> findItem(@NonNull String name) {
        return items.stream().filter(item -> item.getName().equals(name)).findFirst();
    }

    @Override
    public void orderItem(@NonNull String name, int amount) {
        findItem(name).ifPresentOrElse(item -> {
            if (item.getNumberInStorage() >= amount) {
                item.setNumberInStorage(item.getNumberInStorage() - amount);
            } else {
                throw new StorageException("Insufficient amount in storage");
            }
        }, () -> { throw new StorageException("Item not found in storage"); });
    }
}
