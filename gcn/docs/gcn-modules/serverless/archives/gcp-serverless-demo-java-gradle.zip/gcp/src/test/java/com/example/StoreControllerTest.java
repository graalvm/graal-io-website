/*
 * Copyright 2024 Oracle and/or its affiliates
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example;

import io.micronaut.context.annotation.Property;
import io.micronaut.context.annotation.Requires;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.Post;
import io.micronaut.http.client.annotation.Client;
import io.micronaut.http.client.exceptions.HttpClientResponseException;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static io.micronaut.http.HttpStatus.BAD_REQUEST;
import static io.micronaut.http.HttpStatus.NOT_FOUND;
import static io.micronaut.http.HttpStatus.OK;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@MicronautTest
@Property(name = "use-test-storage-service", value = "true")
class StoreControllerTest {

    @Inject
    StoreClient client;

    @Test
    void testAvailableItems() {
        List<StoreItem> availableItems = client.getAvailable();

        assertEquals(2, availableItems.size());
        assertEquals("pot", availableItems.get(1).getName());
        assertEquals(10, availableItems.get(1).getNumberInStorage());
        assertNotNull(availableItems.get(1).getDescription());
    }

    @Test
    void testNotFoundException() {
        HttpResponse<?> response = client.order("lamp", 1);

        assertEquals(NOT_FOUND, response.getStatus());
    }

    @Test
    void testNotSufficientException() {
        HttpClientResponseException e = assertThrows(HttpClientResponseException.class, () -> {
            client.order("pot", 100);
        });

        assertEquals(BAD_REQUEST, e.getStatus());
    }

    @Test
    void testOrderRequest() {
        StoreItem plate = client.getAll().stream()
            .filter(i -> i.getName().equals("plate"))
            .findFirst().orElse(null);
        assertNotNull(plate);
        assertEquals(100, plate.getNumberInStorage());

        HttpResponse<StoreItem> response = client.order("plate", 10);
        assertEquals(OK, response.getStatus());
        assertNotNull(response.body());
        assertEquals("plate", response.body().getName());
        assertEquals(90, response.body().getNumberInStorage());
    }

    @Singleton
    @Requires(property = "use-test-storage-service", value = "true")
    static class TestStorageService extends DefaultStorageService {
        TestStorageService() {
            items = List.of(
                new StoreItem("plate", "A large plate", 100),
                new StoreItem("pot", "A cooking pot", 10),
                new StoreItem("pan", "A large pan", 0)
            );
        }
    }

    @Client("/store")
    interface StoreClient {
        @Get("/all")
        List<StoreItem> getAll();

        @Get("/available")
        List<StoreItem> getAvailable();

        @Post("/order/{name}/{amount}")
        HttpResponse<StoreItem> order(String name, Integer amount);
    }
}
